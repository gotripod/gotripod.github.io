=== Plugin Name ===
Contributors: miletbaker
Tags: flickr, thumbnails, tag, sets, photos
Requires at least: 2.2.1
Tested up to: 2.3.1
Stable tag: trunk

Insert photos from your Flickr PhotoStream, Favorites or Sets into your posts (inserts img tag).

== Description ==

Based on the excellent Flickr Tag plugin by Jeffrey Maki, this takes a different approach and allows you to browse and add photos from your Photostream, Favorites or Sets straight into your post or pages. This inserts an img tag with a link to the photo rather than a special tag that is generated on the fly.

My solution was to write my own plugin.

== Installation ==

1. Uncompress the downloaded archive in [WordPress install root]/wp-content/plugins.

2. Activate the plugin in your WordPress plugins control panel.

3. Go to the "Options" section, then choose "WP-Flickr" to configure the plugin. 

After installation, you'll have a new "WP-Flickr" tab in the "Upload" area that appears when you edit/write posts. Select the size, and click on a thumbnail to insert: 

== Frequently Asked Questions ==

== Screenshots ==

